
---------------------------------------------------------------------------------------
CREATE DATABASE Carga_cliente;

---------------------------------------------------------------------------------------
USE Carga_cliente;

---------------------------------------------------------------------------------------
if object_id('CLIENTE') is not null
  drop table CLIENTE;

CREATE TABLE CLIENTE(

codigo		char(9)		not null,
dni			char(8)		not null,
sexo		varchar(15) not null,
edad		int			not null,
provincia	varchar(50) not null,
base		varchar(50) not null
);

-------------------------------------STAGING--------------------------------------------
--if object_id('STG_CLIENTE') is not null
--  drop table CLIENTE;

--CREATE TABLE STG_CLIENTE(

--codigo		char(9)		not null,
--dni			char(8)		not null,
--sexo		varchar(15) not null,
--edad		int			not null,
--provincia	varchar(50) not null,
--base		varchar(50) not null
--);


---------------------------------------------------------------------------------------
BULK INSERT Carga_cliente..CLIENTE
FROM 'G:\DataGrowth\SQL FOR DATA ANALYTICS\Carga_Masiva\Base_Cliente.csv'
WITH (
		FIRSTROW = 2,
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
		);

---------------------------------------------------------------------------------------
SELECT *
FROM Carga_cliente..CLIENTE



-------------------------------------TEMPORAL------------------------------------------
if object_id('tempdb..#CLIENTE') is not null
  drop table tempdb..#CLIENTE;

CREATE TABLE #CLIENTE(

codigo		char(9)			not null,
dni			char(8)			not null,
sexo		varchar(15)		not null,
fch_nac		varchar(20)		not null,
--edad		int				not null,
provincia	varchar(50)		not null,
--base		varchar(50)		not null
);

BULK INSERT Carga_cliente..#CLIENTE
FROM 'G:\DataGrowth\SQL FOR DATA ANALYTICS\Carga_Masiva\SECTOR-B.csv'
WITH (
		FIRSTROW = 2,
		FIELDTERMINATOR = ',',
		ROWTERMINATOR = '\n'
		);

---------------------------------------------------------------------------------------
set dateformat dmy


---------------------------------------------------------------------------------------
SELECT *, CAST(fch_nac AS date)
FROM tempdb..#CLIENTE


---------------------------------------------------------------------------------------
Select floor(
(cast(convert(varchar(8),getdate(),112) as int)-
cast(convert(varchar(8),CAST(fch_nac AS date),112) as int) ) / 10000 
) as edad, * from tempdb..#CLIENTE

