--Uso del case--

--Categorizar la lista de precios de los productos en Alto, Medio y Bajo--

SELECT Name, ListPrice,
  CASE
    WHEN ListPrice > 1000 THEN 'Alto'
    WHEN ListPrice > 500 AND ListPrice <= 1000 THEN 'Medio'
    ELSE 'Bajo'
  END AS 'Precio'
FROM Production.Product

--CASO PRACTICO--
--Del ejercicio anterior se requiere a�adir otra condicion donde se muestra los precios en las mismas categorias pero 
--adicional mostrar si son con stock y sin stock (en la tabla Production.ProductInventory se encuentra el inventario
--Nota: Solo considerar para el precio alto y medio



--GUID--

--if object_id('Alumno') is not null
--  drop table Alumno;

--CREATE TABLE Alumno(
--	cod_alumno	uniqueidentifier not null default newid(),
--	nombre		varchar(20) not null,
--	edad		int not null
--)

--INSERT INTO Alumno(nombre, edad)
--VALUES ('Jorge', 31),
--	   ('Maria', 25),
--	   ('Carmen', 26),
--	   ('Alejandro', 22)

--SELECT *
--FROM Alumno


--Realizar consultas Aleatorias--
SELECT TOP 1 ProductID, Name, ProductNumber
FROM Production.Product
ORDER BY NEWID()
GO

--Obtener una llave unica, con GUID (NEWID()), limitar rango de extraer datos OFFSET '' ROWSM, FETCH NEXT '' ROWS ONLY;
SELECT 
	REPLACE(CONVERT(VARCHAR(36), NEWID()), '-', '') AS [CODIGO]
	,GETDATE() AS [FECHA_ACTUAL]
	,ProductID
	,Quantity
FROM Production.ProductInventory
WHERE Quantity > 0
ORDER BY NEWID()
OFFSET 0 ROWS
FETCH NEXT 5 ROWS ONLY;



--OFFSET - FETCH--
--ORDER BY column_list [ASC |DESC]
--OFFSET offset_row_count {ROW | ROWS}
--FETCH {FIRST | NEXT} fetch_row_count {ROW | ROWS} ONLY


--Lista de precios de los productos mayores a 0--
SELECT 
	[Name]
	,[ListPrice]

FROM [Production].[Product]
WHERE [ListPrice] > 0
ORDER BY [ListPrice];

--Omitir los 10 primeros productos--
SELECT 
	[Name]
	,[ListPrice]

FROM [Production].[Product]
WHERE [ListPrice] > 0
ORDER BY [ListPrice]
OFFSET 10 ROWS;

--Omitir los 10 primeros productos y traer los 10 siguientes--
SELECT 
	[Name]
	,[ListPrice]
FROM [Production].[Product]
WHERE [ListPrice] > 0
ORDER BY [ListPrice]
OFFSET 10 ROWS
FETCH NEXT 10 ROWS ONLY;

--Obtener los 10 productos mas caros--
SELECT 
	[Name]
	,[ListPrice]
FROM [Production].[Product]
WHERE [ListPrice] > 0
ORDER BY [ListPrice] DESC
OFFSET 0 ROWS
FETCH NEXT 10 ROWS ONLY;

--SELECT TOP 10
--	[Name]
--	,[ListPrice]
--FROM [Production].[Product]
--WHERE [ListPrice] > 0
--ORDER BY [ListPrice] DESC
