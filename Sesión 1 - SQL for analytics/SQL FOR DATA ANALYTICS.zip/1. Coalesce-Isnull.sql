--Diferencia entre COALESCE y ISNULL--

DECLARE @var_1 AS VARCHAR(5) = NULL
	   ,@var_2 AS VARCHAR(9) = '123456789'

SELECT COALESCE(@var_1, @var_2) AS 'COALESCE'
      ,ISNULL(@var_1, @var_2) AS 'ISNULL'



--EJEMPLO--
SELECT 
	[p].[ProductID]
	,[p].[Name]
	,[p].[Size]
	,[p].[SizeUnitMeasureCode]
	,[p].[WeightUnitMeasureCode]
	,[p].[Weight]
	,COALESCE([p].[Size], [p].[SizeUnitMeasureCode], 'EMPTY') AS 'Size'
FROM [Production].[Product] AS [p]
--WHERE
--	ProductID = 827;