--FUNCION LAG / LEAD--

--Ejemplo practico--
SELECT [ProductID]
      ,[LocationID]
      ,[Shelf]
      ,[Bin]
      ,[Quantity]
	  ,LAG(Quantity) OVER(PARTITION BY ProductID ORDER BY ProductID)	AS [AntesQty]
	  ,LEAD(Quantity) OVER(PARTITION BY ProductID ORDER BY ProductID)	AS [DespuesQty]
FROM [Production].[ProductInventory];
--WHERE [ProductID] = 1


--CASO PRACTICO--

--1. Mostrar un comparativo entre A�O, MES de las ventas totales con respecto al A�O Anterior en los a�os 2012 y 2013--
