--SUBCONSULTA CON ANY/ALL--

if object_id('libros') is not null
  drop table libros;
 if object_id('editoriales') is not null
  drop table editoriales;

 create table editoriales(
  codigo tinyint identity,
  nombre varchar(30),
  primary key (codigo)
 );
 
 create table libros (
  codigo int identity,
  titulo varchar(40),
  autor varchar(30),
  codigoeditorial tinyint,
  precio decimal(5,2),
  primary key(codigo),
 constraint FK_libros_editorial
   foreign key (codigoeditorial)
   references editoriales(codigo)
   on update cascade,
 );

 insert into editoriales values('Planeta');
 insert into editoriales values('Emece');
 insert into editoriales values('Paidos');
 insert into editoriales values('Siglo XXI');

 insert into libros values('Uno','Richard Bach',1,15);
 insert into libros values('Ilusiones','Richard Bach',4,18);
 insert into libros values('Puente al infinito','Richard Bach',2,23);
 insert into libros values('Aprenda PHP','Mario Molina',4,40);
 insert into libros values('El aleph','Borges',2,10);
 insert into libros values('Antolog�a','Borges',1,20);
 insert into libros values('Cervantes y el quijote','Borges',3,25);


 select * from editoriales
 select * from libros

 --los t�tulos y precios de los libros "Borges" cuyo precio supera a ALGUN precio de los libros de "Richard Bach"--

--ANY--
 select titulo,precio
  from libros
  where autor like '%Borges%' and
  precio > any
   (select precio
    from libros
    where autor like '%Bach%');

	select titulo,precio
  from libros
  where autor like '%Borges%';

  select precio
    from libros
    where autor like '%Bach%';


--si empleamos "all" en lugar de "any"--

--ALL--
 select titulo,precio
  from libros
  where autor like '%Borges%' and
  precio > all
   (select precio
    from libros
    where autor like '%Bach%');

	select titulo,precio
  from libros
  where autor like '%Borges%';

  select precio
    from libros
    where autor like '%Bach%';


--ALGUNAS DIFERENCIAS DE USAR SUBCONSULTA / JOIN-CTE--

--EJEMPLO JOIN--

--SUBCONSULTA--
SELECT 
	[soh].[SalesOrderNumber]
	,[soh].[OrderDate]
	,[soh].[CustomerID]
	,[soh].[TotalDue]
	,[sod].[ProductID]
	,[sod].[OrderQty]
	,[sod].[UnitPrice]
FROM 
	[Sales].[SalesOrderHeader] AS [soh]
	INNER JOIN [Sales].[SalesOrderDetail] AS [sod]
		ON [soh].[SalesOrderID] = [sod].[SalesOrderID]
WHERE
	[sod].[ProductID] 
	IN 
		(
			SELECT 
				[ProductID]
			FROM
				[Production].[Product] AS [p]
			WHERE 
				[p].[MakeFlag] = 1
		);


--JOIN--
SELECT 
	[oh].[SalesOrderNumber]
	,[oh].[OrderDate]
	,[oh].[CustomerID]
	,[oh].[TotalDue]
	,[od].[ProductID]
	,[od].[OrderQty]
	,[od].[UnitPrice]
FROM 
	[Sales].[SalesOrderHeader] AS [oh]
	INNER JOIN [Sales].[SalesOrderDetail] AS [od]
		ON [oh].[SalesOrderID] = [od].[SalesOrderID]
	INNER JOIN [Production].[Product] AS [p]
		ON [od].[ProductID] = [p].[ProductID]
		AND [p].[MakeFlag] = 1;


--EJEMPLO CTE--

--SUBCONSULTA--
SELECT
	[e1].[BusinessEntityID]
	,[e1].[LoginID]
	,[e1].[JobTitle]
	,[e1].[VacationHours]
	,[Sub].[AverageVacation] 
FROM 
	[HumanResources].[Employee] AS [e1]
	INNER JOIN 
		(
		SELECT
			[e2].[JobTitle]
			,AVG([e2].[VacationHours]) AS [AverageVacation]
		FROM 
			[HumanResources].[Employee] AS [e2]
		GROUP BY 
			[e2].[JobTitle]
		) AS [sub]
	ON [e1].[JobTitle] = [sub].[JobTitle]
WHERE 
	[e1].[VacationHours] > [sub].[AverageVacation]
ORDER BY 
	[e1].[JobTitle];
	
	
--CTE--
WITH CTE_VacationAVG AS
(
	SELECT
		[e2].[JobTitle]
		,AVG([e2].[VacationHours]) AS [AverageVacation]
	FROM 
		[HumanResources].[Employee] AS [e2]
	GROUP BY 
		[e2].[JobTitle]
)

SELECT
	[e1].[BusinessEntityID]
	,[e1].[LoginID]
	,[e1].[JobTitle]
	,[e1].[VacationHours]
	,[cte].[AverageVacation] 
FROM 
	[HumanResources].[Employee] AS [e1]
	INNER JOIN [CTE_VacationAVG] AS [cte]
		ON [e1].[JobTitle] = [cte].[JobTitle]
WHERE 
	[e1].[VacationHours] > [cte].[AverageVacation]
ORDER BY 
	[e1].[JobTitle];

