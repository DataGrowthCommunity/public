--ROW_NUMBER, OVER / PARTITION / ORDER BY--

--VER EL DETALLE DE COMPRAS--
SELECT *
FROM [Purchasing].[PurchaseOrderDetail] AS [pod]
--WHERE [pod].[PurchaseOrderID] = 18

 
--ASIGNARLE UN CONSECUTIVO DE ITEM EN CADA PRODUCTO--
SELECT
	*
	,ROW_NUMBER() OVER(PARTITION BY [purchaseOrderID] ORDER BY [pod].[purchaseOrderID] ) AS 'Item'
FROM [Purchasing].[PurchaseOrderDetail] AS [pod]
--WHERE [pod].[PurchaseOrderID] = 18



--Visualizar minimo, maximo, cantidad, promedio del costo total--
SELECT 
	--[v].[Name],
	[poh].[ShipMethodID]
	,MIN(poh.TotalDue)		AS MinTotal
	,MAX(poh.TotalDue)		AS MaxTotal
	,COUNT(poh.TotalDue)	AS MaxTotal
	,AVG(poh.TotalDue)		AS AVGTotal
FROM [Purchasing].[PurchaseOrderHeader] AS [poh]
	INNER JOIN [Purchasing].[Vendor] AS [v]
		ON [v].[BusinessEntityID] = [poh].[VendorID]
GROUP BY
	[poh].[ShipMethodID]
	--,[v].[Name]


--Usando Over--
SELECT 
	[poh].[VendorID]
	,[v].[Name]
	,[poh].[ShipMethodID]
	,MIN(poh.TotalDue) OVER(PARTITION BY [poh].[ShipMethodID])		AS [MinTotal]
	,MAX(poh.TotalDue) OVER(PARTITION BY [poh].[ShipMethodID])		AS [MaxTotal]
	,COUNT(poh.TotalDue) OVER(PARTITION BY [poh].[ShipMethodID])	AS [CountTotal]
	,AVG(poh.TotalDue) OVER(PARTITION BY [poh].[ShipMethodID])		AS [AVGTotal]
FROM 
	[Purchasing].[PurchaseOrderHeader] AS [poh]
	INNER JOIN [Purchasing].[Vendor] AS [v]
		ON [v].[BusinessEntityID] = [poh].[VendorID]



--Ejemplo con los productos en inventario--

SELECT 
	[LocationID]
	,[Bin]
	,SUM([Quantity])
FROM 
	[Production].[ProductInventory]
GROUP BY
	[LocationID]
	,[Bin]
ORDER BY
	[LocationID]
	,[Bin]


--Usando Over--
SELECT 
	   [ProductID]
      ,[LocationID]
      ,[Bin]
      ,[Quantity]
      ,SUM(Quantity) OVER(PARTITION BY [LocationID], [Bin]) AS [Partition]
FROM 
	[Production].[ProductInventory]


--CASO PRACTICO--

--1. Obtener el total acumulado por a�o y mes de las ventas  (SALES) Sales.SalesOrderHeader--

--2. --2. Calcular la media movil de las ventas anuales por persona (Sales.SalesPerson) y que solo se considere los territorios null o menor a 5 (TerritoryID)--