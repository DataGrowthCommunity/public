--FUNCION MERGE--

--MERGE INTO <target table> AS TGT 
--USING <SOURCE TABLE> AS SRC   
--	ON <merge predicate> 
--WHEN MATCHED [AND <predicate>] -- two clauses allowed:   
--	THEN <action> -- one with UPDATE one with DELETE 
--WHEN NOT MATCHED [BY TARGET] [AND <predicate>] -- one clause allowed:   
--	THEN INSERT... �- if indicated, action must be INSERT 
--WHEN NOT MATCHED BY SOURCE [AND <predicate>] -- two clauses allowed:   
--	THEN <action>; -- one with UPDATE one with DELETE


if object_id('StudentsC1') is not null
  drop table StudentsC1;

CREATE TABLE StudentsC1(
    StudentID		INT
    ,StudentName	VARCHAR(50)
    ,StudentStatus	BIT
);


INSERT INTO StudentsC1(StudentID, StudentName, StudentStatus) VALUES(1,'Axel Romero',1)
INSERT INTO StudentsC1(StudentID, StudentName, StudentStatus) VALUES(2,'Sof�a Mora',1)
INSERT INTO StudentsC1(StudentID, StudentName, StudentStatus) VALUES(3,'Rogelio Rojas',0)
INSERT INTO StudentsC1(StudentID, StudentName, StudentStatus) VALUES(4,'Mariana Rosas',1)
INSERT INTO StudentsC1(StudentID, StudentName, StudentStatus) VALUES(5,'Roman Zavaleta',1)


if object_id('StudentsC2') is not null
  drop table StudentsC2;

CREATE TABLE StudentsC2(
    StudentID		INT
    ,StudentName	VARCHAR(50)
    ,StudentStatus	BIT
);

INSERT INTO StudentsC2(StudentID, StudentName, StudentStatus) VALUES(1,'Axel Romero Rend�n',1)
INSERT INTO StudentsC2(StudentID, StudentName, StudentStatus) VALUES(2,'Sof�a Mora R�os',0)
INSERT INTO StudentsC2(StudentID, StudentName, StudentStatus) VALUES(6,'Mario Gonzalez Pae',1)
INSERT INTO StudentsC2(StudentID, StudentName, StudentStatus) VALUES(7,'Alberto Garc�a Morales',1)


SELECT * FROM StudentsC1
SELECT * FROM StudentsC2


MERGE StudentsC1 AS [tgt]
USING
(
	SELECT
		[s].[StudentID]
		,[s].[StudentName]
		,[s].[StudentStatus]
	FROM 
		StudentsC2 AS [s]
) AS [src]
ON
(
	[src].[StudentID] = [tgt].[StudentID]
)
--UPDATE--
WHEN MATCHED THEN
	UPDATE 
		SET
			[tgt].[StudentName] = [src].[StudentName]
			,[tgt].[StudentStatus] = [src].[StudentStatus]
--INSERT--
WHEN NOT MATCHED THEN
	INSERT
	(
		[StudentID], [StudentName], [StudentStatus]
	)
	VALUES
	(
		[src].[StudentID], [src].[StudentName], [src].[StudentStatus]
	)

--DELETE--
--WHEN NOT MATCHED BY SOURCE THEN 
--	DELETE	

OUTPUT
	$action AS 'action'
	,COALESCE(inserted.StudentID, deleted.StudentID) AS 'StudentID';




